package com.proyectoherbarioitcr.herbariomobile.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.proyectoherbarioitcr.herbariomobile.R;
import com.proyectoherbarioitcr.herbariomobile.fragments.MainActivityFragment;
import com.proyectoherbarioitcr.herbariomobile.fragments.muestraFragment;

import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private muestraFragment fragmentMuestra = null;
    private ArrayList<String> familias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fragmentMuestra = null;

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        //this.familias = getFamilias();
        desplegarFragment_main();
        //Toast.makeText(getApplicationContext(), "antes del et funcion", Toast.LENGTH_LONG).show();
    }

    /*
    private ArrayList<String> getFamilias(){
        ArrayList<String> prueba = new ArrayList<>();
        prueba.add("familia00");
        prueba.add("familia01");
        prueba.add("familia02");
        prueba.add("familia03");
        prueba.add("familia04");
        return prueba;
    }
    */

    private void desplegarFragment_main(){
        Bundle bundle = new Bundle();
        bundle.putSerializable("dataSource",this.familias);

        MainActivityFragment fragment = new MainActivityFragment();
        fragment.setArguments(bundle);

        desplegarFragment(fragment);
        this.fragmentMuestra = null;

        //this.createFragment = null; //es este caso seria para el fragmenteo principal
    }
    private void desplegarFragment_muestra(){
        //Bundle bundle = new Bundle();
        //bundle.putSerializable("dataSource","products");
        fragmentMuestra = new muestraFragment();
        //fragment.setArguments(bundle);
        desplegarFragment(fragmentMuestra);
    }

    private void desplegarFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.content_main, fragment);
        ft.commit();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        //noinspection SimplifiableIfStatement
        switch (item.getItemId()) {
            case R.id.action_settings: //error
                //desplegarFragment_muestra();
                return true;
            case R.id.action_escanearqr:
                escanear_qr();
                desplegarFragment_muestra();
                return true;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void escanear_qr() {
        //Se instancia un objeto de la clase IntentIntegrator
        IntentIntegrator scanIntegrator = new IntentIntegrator(this);
        //Se procede con el proceso de scaneo
        scanIntegrator.initiateScan();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        //Se obtiene el resultado del proceso de scaneo y se parsea
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanningResult != null) {
            //Quiere decir que se obtuvo resultado pro lo tanto:
            //Desplegamos en pantalla el contenido del código de barra scaneado
            //Desplegamos en pantalla el nombre del formato del código de barra scaneado
            String scanContent = scanningResult.getContents();
            String scanFormat = scanningResult.getFormatName();
            Toast.makeText(getApplicationContext(), "Contenido: " + scanContent + '\n' + "Formato2: " + scanFormat, Toast.LENGTH_LONG).show();
        }else{
            //Quiere decir que NO se obtuvo resultado
            Toast toast = Toast.makeText(getApplicationContext(),
                    "No se ha recibido datos del scaneo!", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}
