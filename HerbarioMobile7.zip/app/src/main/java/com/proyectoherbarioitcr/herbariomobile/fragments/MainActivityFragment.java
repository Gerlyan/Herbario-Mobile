package com.proyectoherbarioitcr.herbariomobile.fragments;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.proyectoherbarioitcr.herbariomobile.R;
import com.proyectoherbarioitcr.herbariomobile.ListAdapter.StableArrayAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    private TextView lblLista;
    private ListView listBusqueda;
    private EditText txtBusqueda;
    private Button bBuscar;
    private StableArrayAdapter adapterList;

    private ArrayList<String> familias;
    private ArrayList<String> generos;

    private int busqueda; // elementos a buscar -> 0: familias,  1: generos,  2: especies,  3: muestras
    private String familia;
    private String genero;

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_main, container, false);

        this.familia ="";
        this.genero="";
        this.busqueda =0;

        this.txtBusqueda = (EditText)layout.findViewById(R.id.txtBusqueda);
        this.bBuscar = (Button)layout.findViewById(R.id.bBuscar);
        this.lblLista = (TextView)layout.findViewById(R.id.lblLista);
        this.listBusqueda = (ListView)layout.findViewById(R.id.listBusqueda);

        lblLista.setText("Selccione una familia_prueba");
        ArrayList<String> dataSource = dataSource = (ArrayList<String>)getArguments().getSerializable("dataSource");
        //String n = String.valueOf(dataSource.size());
        //Toast.makeText(layout.getContext(), "prueba: "+ n, Toast.LENGTH_LONG).show();
        this.familias = getFamilias();
        this.listBusqueda.setTextFilterEnabled(true);
        fillListBus(this.familias);

        listBusqueda.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                switch (busqueda) {
                    case 0: {
                        familia = select_familia(parent.getItemAtPosition(position));
                        break;
                    }
                    case 1: {
                        genero = select_genero(parent.getItemAtPosition(position));
                        break;
                    }
                    /*case 2: {
                        especie = select_familia(parent.getItemAtPosition(position));
                        break;
                    }
                    case 3: {
                        muestra = desplegarDstosMustra(parent.getItemAtPosition(position));
                        break;
                    }*/
                }
                busqueda++;
                Toast.makeText(view.getContext() ,familia+"@"+genero, Toast.LENGTH_LONG).show();
            }
        });
        return layout;
    }
    private String select_familia(Object objFamilia){
        this.generos = this.getGeneros(familia);
        fillListBus(this.generos);
        return (String)objFamilia;
    }
    private String select_genero(Object objGenero){
        return (String)objGenero;
    }

    private void fillListBus(ArrayList<String> lista){
        adapterList = new StableArrayAdapter(getActivity(), android.R.layout.simple_list_item_1,lista);
        this.listBusqueda.setAdapter(adapterList);
        //for (int i=0; i<lista.size(); i++){
        //}
    }
    private ArrayList<String> getFamilias(){
        ArrayList<String> prueba = new ArrayList<>();
        prueba.add("familia00");
        prueba.add("familia01");
        prueba.add("familia02");
        prueba.add("familia03");
        prueba.add("familia04");
        return prueba;
    }
    private ArrayList<String> getGeneros(String nFamilia){
        ArrayList<String> prueba = new ArrayList<>();
        prueba.add("Genero00");
        prueba.add("Genero01");
        prueba.add("Genero02");
        prueba.add("Genero03");
        prueba.add("Genero04");
        return prueba;
    }
}
