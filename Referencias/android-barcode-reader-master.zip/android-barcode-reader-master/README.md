# android-barcode-reader
Aprenda a trabalhar com código de barras em seu app Android. Veja como criar uma lista de produtos em memória permitindo ao usuário adicionar novos elementos, capturar o código de barras pela câmera do celular usando a api ZXing e realizar toda a integração através de Listeners.

# antes de começar
O projeto foi construido usando como base o componente ZXing que por sua vez será baixado via dependência usando Gradle
Também usei um Adapter Customizado por mim que foi explicado no detalhe no vídeo seguinte
https://www.youtube.com/watch?v=4czLIVDP8Zs&list=PL4G9uRWxf6dZVNFiNXch2NnVGa9KOMBDk&index=15

# vídeo de apresentação do projeto
https://youtu.be/5EkE6QLNRFU

# vídeo explicativo mostrando como o projeto foi desenvolvido
https://youtu.be/LMnoKmRNRLg
